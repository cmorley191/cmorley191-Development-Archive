package caseengine;

import java.util.ArrayList;

/**
 * Orders the updating of a set of {@link ThresholdNode ThresholdNodes}.
 * <p>
 * Synchronized.
 * 
 * @author Charlie Morley
 *
 */
final class NodeUpdateSequencer {

	private static final int SEQUENCING_SCHEME_AWAITING_UPDATE = -1;
	/**
	 * Sequencing scheme that selects a random node from the list to update.
	 */
	static final int SEQUENCING_SCHEME_RANDOM = 0;
	/**
	 * Sequencing scheme that selects a random node from the list to update, but
	 * ensures each node is updated before updating a node a second time. New
	 * nodes are added to the list immediately - the sequencer does not wait for
	 * the list to repeat to add new nodes.
	 */
	static final int SEQUENCING_SCHEME_RANDOM_BALANCED = 1;
	/**
	 * Sequencing scheme that updates nodes in the order they are added to the
	 * sequencer (the order returned by {@link #getNodes()}). So, new nodes are
	 * added to the end of the order.
	 */
	static final int SEQUENCING_SCHEME_ORDERED = 2;
	/**
	 * Sequencing scheme that updates nodes in a constant order that is randomly
	 * determined once the scheme is set. New nodes are added randomly to the
	 * order.
	 */
	static final int SEQUENCING_SCHEME_ORDERED_RANDOMLY = 3;
	private static final int SEQUENCING_SCHEME_NULL = 4;

	private int sequencingScheme;
	private ArrayList<ThresholdNode> nodes = new ArrayList<ThresholdNode>();
	private ArrayList<ThresholdNode> sequencedNodes = new ArrayList<ThresholdNode>();

	/**
	 * Synchronizing variables that ensure that changes to the sequencer do not
	 * occur in the middle of an update.
	 */
	private int updatedSequencingScheme = SEQUENCING_SCHEME_AWAITING_UPDATE;
	private ArrayList<ThresholdNode> addedNodes = new ArrayList<ThresholdNode>();
	private ArrayList<ThresholdNode> removedNodes = new ArrayList<ThresholdNode>();

	NodeUpdateSequencer(int sequencingScheme) {
		if (isValidSequencingScheme(sequencingScheme))
			this.sequencingScheme = sequencingScheme;
		else
			this.sequencingScheme = SEQUENCING_SCHEME_RANDOM;
	}

	private static boolean isValidSequencingScheme(int sequencingScheme) {
		return (sequencingScheme > SEQUENCING_SCHEME_AWAITING_UPDATE && sequencingScheme < SEQUENCING_SCHEME_NULL);
	}

	NodeUpdateSequencer() {
		this(SEQUENCING_SCHEME_RANDOM);
	}

	int getSequencingScheme() {
		return sequencingScheme;
	}

	void setSequencingScheme(int sequencingScheme) {
		if (isValidSequencingScheme(sequencingScheme)
				&& this.sequencingScheme != sequencingScheme)
			updatedSequencingScheme = sequencingScheme;
	}

	ArrayList<ThresholdNode> getNodes() {
		ArrayList<ThresholdNode> list = new ArrayList<ThresholdNode>();
		list.addAll(nodes);
		return list;
	}

	void addNode(ThresholdNode node) {
		if (node != null)
			addedNodes.add(node);
	}

	void removeNode(ThresholdNode node) {
		if (node != null)
			removedNodes.remove(node);
	}

	void updateNext() {
		synchronizeChanges();
		if (sequencingScheme == SEQUENCING_SCHEME_RANDOM) {
			nodes.get((int) (Math.random() * nodes.size())).updateAndLearn();
			return;
		}
		sequencedNodes.get(0).update();
		if (sequencingScheme == SEQUENCING_SCHEME_RANDOM_BALANCED) {
			sequencedNodes.remove(0);
		} else {
			ThresholdNode node = sequencedNodes.get(0);
			sequencedNodes.remove(0);
			sequencedNodes.add(node);
		}
	}

	private void synchronizeChanges() {
		if (updatedSequencingScheme != SEQUENCING_SCHEME_AWAITING_UPDATE) {
			sequencedNodes.clear();
			sequencingScheme = updatedSequencingScheme;
			updatedSequencingScheme = SEQUENCING_SCHEME_AWAITING_UPDATE;

			if (sequencingScheme == SEQUENCING_SCHEME_ORDERED)
				sequencedNodes.addAll(nodes);
		}
		if (sequencedNodes.size() == 0
				&& (sequencingScheme == SEQUENCING_SCHEME_RANDOM_BALANCED || sequencingScheme == SEQUENCING_SCHEME_ORDERED_RANDOMLY)) {
			ArrayList<ThresholdNode> list = new ArrayList<ThresholdNode>();
			list.addAll(nodes);
			while (list.size() > 0) {
				ThresholdNode node = list.get((int) (Math.random() * list
						.size()));
				list.remove(node);
				sequencedNodes.add(node);
			}
		}
		for (ThresholdNode node : addedNodes) {
			nodes.add(node);
			if (sequencingScheme == SEQUENCING_SCHEME_RANDOM_BALANCED
					|| sequencingScheme == SEQUENCING_SCHEME_ORDERED_RANDOMLY)
				sequencedNodes.add((int) (Math.random() * nodes.size()), node);
			else if (sequencingScheme == SEQUENCING_SCHEME_ORDERED)
				sequencedNodes.add(node);
		}
		addedNodes.clear();
		for (ThresholdNode node : removedNodes) {
			nodes.remove(node);
			if (sequencingScheme != SEQUENCING_SCHEME_RANDOM)
				sequencedNodes.remove(node);
		}
		removedNodes.clear();
	}
}
