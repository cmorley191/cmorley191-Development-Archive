package caseengine;

import java.util.HashMap;
import java.util.Map.Entry;

/**
 * A neural network node that receives weighted input from other nodes. Changes
 * its output based on whether the sum of its weighted inputs overcomes its
 * threshold whenever its {@link #update()} is called.
 * 
 * @author Charlie Morley
 *
 */
public final class ThresholdNode extends Node {

	/**
	 * The collection of inputting nodes and the weights of their inputs.
	 */
	private HashMap<Node, Double> connections = new HashMap<Node, Double>();

	/**
	 * The threshold the collection of weighted inputs needs to overcome for
	 * this node to output positively.
	 */
	private double threshold;

	/**
	 * Creates a node with the specified threshold.
	 * 
	 * @param threshold
	 *            the threshold this node's weighted inputs need to overcome to
	 *            generate a positive output
	 */
	public ThresholdNode(double threshold) {
		super();
		this.threshold = threshold;
	}

	/**
	 * Sets a connection from the specified node's output to this node with the
	 * specified weight.
	 * 
	 * @param node
	 *            the node this node receives input from
	 * @param weight
	 *            the weight of the connection between the specified node and
	 *            this node
	 */
	public void setConnection(Node node, double weight) {
		connections.put(node, weight);
	}

	/**
	 * Returns the threshold value the sum of weighted inputs of this node needs
	 * to overcome to set this node's state to positive.
	 * 
	 * @return the threshold of this node
	 */
	public double getThreshold() {
		return threshold;
	}

	/**
	 * Updates the state of this node based on its inputs.
	 * <p>
	 * Sums the weighted inputs of all its nodes and changes the state to
	 * {@code true} if it is greater than or equal to the threshold of this
	 * node, {@code false} if less than the threshold.
	 */
	void update() {
		double input = 0;
		for (Entry<Node, Double> entry : connections.entrySet())
			input += entry.getValue() * entry.getKey().getOutput();
		active = input >= threshold;
	}
	
	private final static double LEARNING_INCREMENT = 0.01;
	
	void learn() {
		for (Entry<Node, Double> entry : connections.entrySet())
			if ((entry.getKey().active == (entry.getValue() >= 0)) == active)
				connections.put(entry.getKey(), entry.getValue() + LEARNING_INCREMENT);
			else
				connections.put(entry.getKey(), entry.getValue() - LEARNING_INCREMENT);
	}
	
	void updateAndLearn() {
		update();
		learn();
	}
}
