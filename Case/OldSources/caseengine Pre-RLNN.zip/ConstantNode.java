package caseengine;

/**
 * A neural network node with an unchanging activity.
 * 
 * @author Charlie Morley
 *
 */
final class ConstantNode extends Node {

	/**
	 * Constructs a node with the specified activity.
	 * 
	 * @param active
	 *            the activity of this node
	 */
	public ConstantNode(boolean active) {
		super();
		this.active = active;
	}
}
