package rewardfield;

import java.util.ArrayList;

import caseengine.Mind;
import caseengine.Node;
import caseengine.ThresholdNode;

public class Bot implements Runnable {

	private Mind mind = new Mind();
	private ArrayList<Input> inputs = new ArrayList<Input>();
	private ArrayList<ThresholdNode> outputs = new ArrayList<ThresholdNode>();

	private boolean running = true;

	private int x;
	private int y;

	private double[][] rewardField;

	public Bot(double[][] rewardField) {
		ArrayList<ThresholdNode> brainNetwork = new ArrayList<ThresholdNode>();
		for (int i = 0; i < 100; i++) {
			brainNetwork.add(new ThresholdNode(1));
			mind.addNode(brainNetwork.get(i));
			if (i > 97)
				outputs.add(brainNetwork.get(i));
		}
		for (int i = 0; i < brainNetwork.size(); i++) {
			for (int j = 0; j < brainNetwork.size(); j++) {
				if (i != j)
					brainNetwork.get(i).setConnection(brainNetwork.get(j),
							(Math.random() * 2.0) - 1.0);
			}
		}
		for (int i = 0; i < 4; i++) {
			inputs.add(new Input());
			mind.addInput(inputs.get(i));
		}
		x = rewardField.length / 2;
		if (rewardField.length > 0)
			y = rewardField[0].length / 2;
		else
			y = 0;
		this.rewardField = rewardField;
		update();
	}

	class Input extends Node {
		void setActive(boolean active) {
			this.active = active;
		}
	}

	public void stop() {
		running = false;
	}

	private final static long UPDATE_INTERVAL = 750;

	@Override
	public void run() {
		Thread mindThread = new Thread(mind);
		mindThread.start();
		long previousTime = System.currentTimeMillis();
		while (running) {
			if (System.currentTimeMillis() - previousTime >= UPDATE_INTERVAL) {
				update();
				previousTime = System.currentTimeMillis();
			}
		}
		running = true;
		mind.stop();
	}

	private void update() {
		x += outputs.get(0).getOutput();
		y += outputs.get(1).getOutput();
		if (x < 0)
			x = 0;
		else if (x >= rewardField.length)
			x = rewardField.length - 1;
		if (y < 0)
			y = 0;
		else if (y >= rewardField[x].length)
			y = rewardField[x].length - 1;
		System.out.print("New position: (" + x + ", " + y + ") ");
		int reward = 0;
		int i = 0;
		for (; i < rewardField[x][y]; i++) {
			inputs.get(i).setActive(true);
			reward++;
		}
		for (; i < 4; i++)
			inputs.get(i).setActive(false);
		System.out.println(" Reward: " + reward);
	}
}
