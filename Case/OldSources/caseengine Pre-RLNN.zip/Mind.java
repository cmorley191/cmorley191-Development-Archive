package caseengine;

import java.util.ArrayList;

public class Mind implements Runnable {

	private NodeUpdateSequencer sequencer = new NodeUpdateSequencer();
	
	private ArrayList<Node> inputs = new ArrayList<Node>();
	
	private boolean running = true;
	
	public ArrayList<ThresholdNode> getNodes() {
		return sequencer.getNodes();
	}
	
	public void addNode(ThresholdNode node) {
		sequencer.addNode(node);
	}
	
	public void removeNode(ThresholdNode node) {
		sequencer.removeNode(node);
	}
	
	public ArrayList<Node> getInputs() {
		ArrayList<Node> list = new ArrayList<Node>();
		list.addAll(inputs);
		return list;
	}
	
	public void addInput(Node node) {
		if (node != null)
			inputs.add(node);
	}
	
	public void removeInput(Node node) {
		if (node != null)
			inputs.remove(node);
	}
	
	public void stop() {
		this.running = false;
	}

	@Override
	public void run() {
		while (running) {
			sequencer.updateNext();
		}
		running = true;
	}
}
