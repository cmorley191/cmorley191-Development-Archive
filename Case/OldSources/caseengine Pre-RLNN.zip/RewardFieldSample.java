package rewardfield;

public class RewardFieldSample {
	
	public static void main(String[] args) {
		double[][] rewardField = {{1, 3, 2, 1}, {3, 2, 0, 4}, {2, 0, 2, 3}, {1, 2, 2, 1}};
		new Thread(new Bot(rewardField)).start();
	}
}
