package caseengine;

/**
 * A neural network node outputting either a positive or negative signal.
 * 
 * @author Charlie Morley
 *
 */
public abstract class Node {

	/**
	 * Whether or not this node's output is currently positive.
	 */
	protected boolean active = false;

	/**
	 * Constructs a node outputting a negative value.
	 */
	public Node() {

	}

	/**
	 * Returns {@code true} if this node is outputting a positive signal,
	 * {@code false} if outputting a negative signal.
	 * 
	 * @return the current state of this node
	 */
	public boolean isActive() {
		return active;
	}

	/**
	 * Returns {@code 1.0} if this node is active, otherwise {@code -1.0}.
	 * 
	 * @return the activity of this node in number form
	 */
	public double getOutput() {
		return (active) ? 1.0 : -1.0;
	}
}
